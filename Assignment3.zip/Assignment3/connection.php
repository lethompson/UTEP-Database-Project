<?php

$server     = "localhost";//earth.cs.utep.edu
$username   = "root";//cs_lethompson
$password   = "205cuPA!";//UTEP password
$db         = "CS4342"; //team 08 database: f17cs4342team08

// Create a connection
$conn = mysqli_connect( $server, $username, $password, $db );

// Check connection
if (!$conn) {
    die( "Connection failed: " . mysqli_connect_error() );
}

// echo "Connected successfully to a Database!";

?>